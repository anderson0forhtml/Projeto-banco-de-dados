import tkinter as tk
from tkinter import messagebox, font
import psycopg2

class DatabaseConnector:
    def __init__(self, dbname="20221214010031", user="postgres", password="pabd", host="localhost", port="5432"):
        self.dbname = dbname
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.conn = None
        self.cur = None

    def connect(self):
        try:
            self.conn = psycopg2.connect(
                dbname=self.dbname,
                user=self.user,
                password=self.password,
                host=self.host,
                port=self.port
            )
            self.cur = self.conn.cursor()
        except Exception as error:
            print(f"Erro na conexão: {error}")

    def fetch_data(self):
        try:
            self.cur.execute('SELECT * FROM artista')
            artistas = self.cur.fetchall()
            self.cur.execute('SELECT * FROM musica')
            musicas = self.cur.fetchall()
            return artistas, musicas
        except Exception as e:
            print(f"Erro ao obter dados: {e}")
            return [], []

    def close(self):
        if self.cur:
            self.cur.close()
        if self.conn:
            self.conn.close()

class Artista:
    def __init__(self, db_connector):
        self.db_connector = db_connector

    def cadastrar(self, ID, name, real_name, country):
        try:
            self.db_connector.cur.execute(
                "INSERT INTO artista (IDa, nome_artista, nome_real, pais) VALUES (%s, %s, %s, %s)",
                (ID, name, real_name, country)
            )
            self.db_connector.conn.commit()
            return True
        except Exception as e:
            print(f"Erro ao criar artista: {e}")
            return False

class Musica:
    def __init__(self, db_connector, titulo, idioma, IDa):
        self.db_connector = db_connector
        self.titulo = titulo
        self.idioma = idioma
        self.IDa = IDa

    def lancar(self):
        try:
            self.db_connector.cur.execute(
                "INSERT INTO musica (titulo, idioma, IDa) VALUES (%s, %s, %s)",
                (self.titulo, self.idioma, self.IDa)
            )
            self.db_connector.conn.commit()
            return True
        except Exception as e:
            print(f"Erro ao lançar música: {e}")
            return False

class ArtistaCadastroApp:
    def __init__(self, root, db_connector):
        self.root = root
        self.root.geometry('300x300')
        self.root.title("Cadastro de Artista")
        self.root.configure(bg='black')

        self.button_font = font.Font(family="Spotify Circular", size=10, weight="bold")
        self.label_font = font.Font(family="Spotify Circular", size=8, weight="bold")

        self.db_connector = db_connector
        self.artista_db = Artista(self.db_connector)

        self.janelas()

    def janelas(self):
        tk.Label(self.root, text="ID do Artista", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_id = tk.Entry(self.root)
        self.entry_id.pack(pady=3)

        tk.Label(self.root, text="Nome de Artista", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_name = tk.Entry(self.root)
        self.entry_name.pack(pady=3)

        tk.Label(self.root, text="Nome Real", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_real_name = tk.Entry(self.root)
        self.entry_real_name.pack(pady=3)

        tk.Label(self.root, text="País", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_country = tk.Entry(self.root)
        self.entry_country.pack(pady=3)

        tk.Button(self.root, text="Cadastrar Artista", command=self.ocadastrar, font=self.button_font, bg='#1DB954').pack(pady=3)
        tk.Button(self.root, text="Lançar Música", command=self.show_musica_lancamento, font=self.button_font, bg='#1DB954').pack(pady=3)
        tk.Button(self.root, text="Visualizar Dados", command=self.show_visualizacao, font=self.button_font, bg='#1DB954').pack(pady=3)

    def ocadastrar(self):
        ID = self.entry_id.get()
        name = self.entry_name.get()
        real_name = self.entry_real_name.get()
        country = self.entry_country.get()

        if not ID or not name or not real_name or not country:
            messagebox.showwarning("Validação", "Preencha todos os campos.")
            return

        try:
            ID = int(ID)
            if self.artista_db.cadastrar(ID, name, real_name, country):
                messagebox.showinfo("Sucesso", "Artista cadastrado com sucesso!")
                self.limpar()
            else:
                messagebox.showerror("Erro", "Erro ao cadastrar artista.")
        except ValueError:
            messagebox.showerror("Erro", "ID deve ser um número.")

    def limpar(self):
        self.entry_id.delete(0, tk.END)
        self.entry_name.delete(0, tk.END)
        self.entry_real_name.delete(0, tk.END)
        self.entry_country.delete(0, tk.END)

    def show_musica_lancamento(self):
        self.root.withdraw()
        lanc = tk.Toplevel(self.root)
        MusicaLancamento(lanc, self.db_connector, self.root)

    def show_visualizacao(self):
        self.root.withdraw()
        vis = tk.Toplevel(self.root)
        App(vis, self.db_connector)

class MusicaLancamento:
    def __init__(self, lanc, db_connector, main_app):
        self.lanc = lanc
        self.lanc.geometry('300x300')
        self.lanc.title("Lançamento de Música")
        self.lanc.configure(bg='black')
        self.db_connector = db_connector
        self.main_app = main_app

        tk.Label(self.lanc, text="Título da Música", bg='#1DB954').pack(pady=3)
        self.entry_titulo = tk.Entry(self.lanc)
        self.entry_titulo.pack(pady=3)

        tk.Label(self.lanc, text="Idioma da Música", bg='#1DB954').pack(pady=3)
        self.entry_idioma = tk.Entry(self.lanc)
        self.entry_idioma.pack(pady=3)

        tk.Label(self.lanc, text="ID do Artista", bg='#1DB954').pack(pady=3)
        self.entry_ida = tk.Entry(self.lanc)
        self.entry_ida.pack(pady=3)

        tk.Button(self.lanc, text="Lançar Música", command=self.lancar, bg='#1DB954').pack(pady=3)
        tk.Button(self.lanc, text="Voltar", command=self.voltar_cadastro, bg='#1DB954').pack(pady=3)

    def lancar(self):
        titulo = self.entry_titulo.get()
        idioma = self.entry_idioma.get()
        IDa = self.entry_ida.get()

        if not titulo or not idioma or not IDa:
            messagebox.showerror("Erro", "Todos os campos devem ser preenchidos.")
            return

        try:
            IDa = int(IDa)
            musica = Musica(self.db_connector, titulo, idioma, IDa)
            if musica.lancar():
                messagebox.showinfo("Sucesso", "Música lançada com sucesso!")
                self.entry_titulo.delete(0, tk.END)
                self.entry_idioma.delete(0, tk.END)
                self.entry_ida.delete(0, tk.END)
            else:
                messagebox.showerror("Erro", "Erro ao lançar música.")
        except ValueError:
            messagebox.showerror("Erro", "ID do Artista deve ser um número.")

    def voltar_cadastro(self):
        self.lanc.destroy()
        self.main_app.deiconify()

class App:
    def __init__(self, root, db_connector):
        self.root = root
        self.root.geometry('600x400')
        self.root.title("Visualizador de Tabelas")
        self.root.configure(bg='black')

        self.title_font = font.Font(family="Arial", size=16, weight="bold")
        self.text_font = font.Font(family="Arial", size=10)

        self.db_connector = db_connector

        tk.Button(self.root, text="Carregar Dados", command=self.load_data, bg='#1DB954', font=self.title_font).pack(pady=20)

        self.text_area = tk.Text(self.root, wrap='word', font=self.text_font, bg='white')
        self.text_area.pack(expand=True, fill='both', padx=10, pady=10)

    def load_data(self):
        artistas, musicas = self.db_connector.fetch_data()
        self.text_area.delete(1.0, tk.END)

        if not artistas and not musicas:
            self.text_area.insert(tk.END, "Nenhum dado encontrado.")
            return

        self.text_area.insert(tk.END, "Artistas:\n")
        for artista in artistas:
            self.text_area.insert(tk.END, f"ID: {artista[0]}, Nome: {artista[1]}, Nome Real: {artista[2]}, País: {artista[3]}\n")

        self.text_area.insert(tk.END, "\nMúsicas:\n")
        for musica in musicas:
            self.text_area.insert(tk.END, f"Título: {musica[0]}, Idioma: {musica[1]}, ID Artista: {musica[2]}\n")

if __name__ == "__main__":
    root = tk.Tk()
    db_connector = DatabaseConnector()
    db_connector.connect()
    app = ArtistaCadastroApp(root, db_connector)
    root.protocol("WM_DELETE_WINDOW", lambda: [db_connector.close(), root.destroy()])
    root.mainloop()
