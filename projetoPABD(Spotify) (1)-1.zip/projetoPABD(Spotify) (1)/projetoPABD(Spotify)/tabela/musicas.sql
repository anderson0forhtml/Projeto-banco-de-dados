CREATE TABLE musica (
    titulo varchar(200),
    idioma varchar(50),
    IDa INT NOT NULL,
    FOREIGN KEY (IDa) REFERENCES artista(IDa)
);
