CREATE TABLE artista (
    IDa int PRIMARY KEY not null,
    nome_artista VARCHAR(100),
    nome_real VARCHAR(100),
    pais VARCHAR(100)
);