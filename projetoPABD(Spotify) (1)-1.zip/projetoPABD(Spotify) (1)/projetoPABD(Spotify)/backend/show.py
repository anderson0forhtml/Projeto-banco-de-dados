import psycopg2

class DatabaseConnector:
    def __init__(self, dbname="your_dbname", user="your_user", password="your_password", host="localhost", port="5432"):
        self.dbname = dbname
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.conn = None
        self.cur = None

    def connect(self):
        try:
            self.conn = psycopg2.connect(
                dbname=self.dbname,
                user=self.user,
                password=self.password,
                host=self.host,
                port=self.port
            )
            self.cur = self.conn.cursor()
            print("Conexão estabelecida com sucesso.")
        except Exception as error:
            print(f"Erro na conexão: {error}")

    def fetch_data(self):
        try:
            self.cur.execute('SELECT * FROM artista')
            artistas = self.cur.fetchall()

            self.cur.execute('SELECT * FROM musica')
            musicas = self.cur.fetchall()

            return artistas, musicas
        except Exception as e:
            print(f"Erro ao obter dados: {e}")
            return [], []

    def close(self):
        if self.cur:
            self.cur.close()
        if self.conn:
            self.conn.close()
        print("Conexão fechada.")
