import psycopg2

class Musica:
    def __init__(self, titulo, idioma, IDa, dbname="20221214010031", user="postgres", password="pabd", host="localhost", port="5432"):
        self.titulo = titulo
        self.idioma = idioma
        self.IDa = IDa
        self.dbname = dbname
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.conn = None
        self.cur = None

    def conectar(self):
        try:
            self.conn = psycopg2.connect(
                dbname=self.dbname,
                user=self.user,
                password=self.password,
                host=self.host,
                port=self.port
            )
            self.cur = self.conn.cursor()
            print("Conexão estabelecida com sucesso.")
        except Exception as error:
            print(f"Erro na conexão: {error}")
            raise

    def lancar(self):
        try:
            if self.cur:
                self.cur.execute(
                    "INSERT INTO musica (titulo, idioma, IDa) VALUES (%s, %s, %s)",
                    (self.titulo, self.idioma, self.IDa)
                )
                self.conn.commit()
                print("Música lançada com sucesso.")
        except Exception as e:
            print(f"Erro ao lançar música: {e}")
            raise

    def fechar_conexao(self):
        if self.cur:
            self.cur.close()
        if self.conn:
            self.conn.close()
        print("Conexão fechada.")
