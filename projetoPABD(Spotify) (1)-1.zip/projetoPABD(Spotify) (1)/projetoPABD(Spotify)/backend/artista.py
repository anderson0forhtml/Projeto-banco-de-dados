import psycopg2

class Artista:
    def __init__(self, dbname="20221214010031", user="postgres", password="pabd", host="localhost", port="5432"):
        self.dbname = dbname
        self.user = user
        self.password = password
        self.host = host
        self.port = port
        self.conn = None
        self.cur = None

    def connect(self):
        try:
            self.conn = psycopg2.connect(
                dbname=self.dbname,
                user=self.user,
                password=self.password,
                host=self.host,
                port=self.port
            )
            self.cur = self.conn.cursor()
            print("Conexão estabelecida com sucesso.")
        except (Exception, psycopg2.DatabaseError) as error:
            print(f"Erro na conexão: {error}")

    def obter_artistas(self):
        if self.cur:
            try:
                self.cur.execute('SELECT * FROM artista')
                resultado = self.cur.fetchall()
                return resultado
            except Exception as e:
                print(f"Erro ao obter artistas: {e}")
        return []

    def fechar_conexao(self):
        if self.cur:
            self.cur.close()
        if self.conn:
            self.conn.close()
        print("Conexão fechada.")
