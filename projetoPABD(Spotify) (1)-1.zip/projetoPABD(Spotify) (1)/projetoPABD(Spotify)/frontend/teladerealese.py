import tkinter as tk
from tkinter import messagebox
from backend.musica import Musica

class Reale:
    def __init__(self, lanc):
        self.lanc = lanc
        self.lanc.geometry('600x600')
        self.lanc.title("Tela de Lançamento")
        self.lanc.configure(bg='black')

        tk.Label(self.lanc, text="Título da Música", bg='#1DB954').pack(pady=3)
        self.entry_titulo = tk.Entry(self.lanc)
        self.entry_titulo.pack(pady=3)

        tk.Label(self.lanc, text='Idioma da Música', bg='#1DB954').pack(pady=3)
        self.entry_idioma = tk.Entry(self.lanc)
        self.entry_idioma.pack(pady=3)

        tk.Label(self.lanc, text='ID do Artista', bg='#1DB954').pack(pady=3)
        self.entry_ida = tk.Entry(self.lanc)
        self.entry_ida.pack(pady=3)

        tk.Button(self.lanc, text="Lançar Música", command=self.lancar).pack(pady=3)

    def lancar(self):
        titulo = self.entry_titulo.get()
        idioma = self.entry_idioma.get()
        IDa = self.entry_ida.get()

        if not titulo or not idioma or not IDa:
            messagebox.showerror("Erro", "Todos os campos devem ser preenchidos.")
            return
        
        try:
            IDa = int(IDa)
            musica = Musica(titulo, idioma, IDa)
            musica.conectar()
            musica.lancar()
            musica.fechar_conexao()
            messagebox.showinfo("Sucesso", "Música lançada com sucesso!")
        except ValueError:
            messagebox.showerror("Erro", "ID do Artista deve ser um número.")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao lançar música: {e}")
