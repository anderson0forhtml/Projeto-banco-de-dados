import tkinter as tk
from tkinter import messagebox, font
from backend.artista import Artista

class ArtistaCadastroApp:
    def __init__(self, root):
        self.root = root
        self.root.geometry('600x600')
        self.root.title("Tela de Cadastro do Artista")
        self.root.configure(bg='black')

        self.button_font = font.Font(family="Spotify Circular", size=15, weight="bold")
        self.label_font = font.Font(family="Spotify Circular", size=10, weight="bold")

        self.artista_db = Artista()
        self.artista_db.connect()

        self.janelasc()

    def janelasc(self):
        tk.Label(self.root, text="Email", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_email = tk.Entry(self.root)
        self.entry_email.pack(pady=3)

        tk.Label(self.root, text="Seu Nome de Artista", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_name = tk.Entry(self.root)
        self.entry_name.pack(pady=3)

        tk.Label(self.root, text="Seu Nome Real", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_real_name = tk.Entry(self.root)
        self.entry_real_name.pack(pady=3)

        tk.Label(self.root, text="País em que você se localiza", bg='#1DB954', font=self.label_font).pack(pady=3)
        self.entry_country = tk.Entry(self.root)
        self.entry_country.pack(pady=3)

        tk.Button(self.root, text="Se Cadastrar", command=self.ocadastrar, font=self.button_font, bg='#1DB954').pack(pady=3)

    def cadastrar(self, ID, name, real_name, country):
        try:
            self.artista_db.cur.execute(
                "INSERT INTO artista (IDa, nome_artista, nome_real, pais) VALUES (%s, %s, %s, %s)",
                (ID, name, real_name, country)
            )
            self.artista_db.conn.commit()
            messagebox.showinfo("Sucesso", "Perfil de artista criado! Pronto para seu primeiro lançamento?")
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao criar artista: {e}")

    def ocadastrar(self):
        ID = self.entry_email.get()  
        name = self.entry_name.get()
        real_name = self.entry_real_name.get()
        country = self.entry_country.get()

        if not ID or not name or not real_name or not country:
            messagebox.showwarning("Validação", "Por favor, preencha todos os campos.")
            return

        self.cadastrar(ID, name, real_name, country)

    def __del__(self):
        self.artista_db.fechar_conexao()
