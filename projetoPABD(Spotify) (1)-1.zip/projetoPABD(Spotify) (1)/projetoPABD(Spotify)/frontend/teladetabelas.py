import tkinter as tk
from tkinter import messagebox, font
from backend.show import DatabaseConnector 

class App:
    def __init__(self, root):
        self.root = root
        self.root.geometry('600x400')
        self.root.title("Visualizador de Tabelas")
        self.root.configure(bg='black')

        self.title_font = font.Font(family="Arial", size=16, weight="bold")
        self.text_font = font.Font(family="Arial", size=10)

        self.db = DatabaseConnector()
        self.db.connect()

        tk.Button(self.root, text="Carregar Dados", command=self.load_data, bg='#1DB954', font=self.title_font).pack(pady=20)

        self.text_area = tk.Text(self.root, wrap='word', font=self.text_font, bg='white')
        self.text_area.pack(expand=True, fill='both', padx=10, pady=10)

    def load_data(self):
        artistas, musicas = self.db.fetch_data()
        
        self.text_area.delete(1.0, tk.END) 

        if artistas:
            self.text_area.insert(tk.END, "Artistas:\n")
            for artista in artistas:
                self.text_area.insert(tk.END, f"{artista}\n")

        if musicas:
            self.text_area.insert(tk.END, "\nMúsicas:\n")
            for musica in musicas:
                self.text_area.insert(tk.END, f"{musica}\n")

        if not artistas and not musicas:
            messagebox.showwarning("Aviso", "Nenhum dado encontrado.")

    def __del__(self):
        self.db.close()

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
